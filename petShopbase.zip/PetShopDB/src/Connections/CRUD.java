package Connections;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class CRUD { 
    
    private Connection connection;

    //funções CRUD:
    
    //CRUD criar tabela:
    
    public void createTable(String tableName, String tableContents){
        /*
            void createTable(nome, conteúdos):
                pede um nome e conteúdos de uma tabela;
                cria uma tabela com o nome e váriaveis que foram especificadas
        */
        
        try{
            connection = DriverManager.getConnection("jdbc:sqlite:bancoDeDados.db");
            Statement statement = connection.createStatement();
            statement.setQueryTimeout(30);
            
            statement.executeUpdate("DROP TABLE IF EXISTS " + tableName);
            String s = "CREATE TABLE " + tableName + "(" + tableContents + ")";
            statement.executeUpdate(s);
        }
        catch(SQLException e){System.err.println(e.getMessage());}
    }
    
    //CRUD ler tabela:
    
    public void readTable(String table, String[] var){
        /*
            void readTable(tabela, o que ler):
                pede uma tabela e quais valores serão lidos;
                printa todas as entradas nos valores especificados da tabela escolhida
        */
        
        try{
            connection = DriverManager.getConnection("jdbc:sqlite:bancoDeDados.db");
            Statement statement = connection.createStatement();
            statement.setQueryTimeout(30);
            
            ResultSet rs = statement.executeQuery("SELECT * FROM " + table);
            while(rs.next()) {
                // Ler os dados inseridos
                for(int i = 0; i < var.length; i++ ){
                    System.out.println(var[i] + ": " + rs.getString(var[i]));
                }
                System.out.println(" --- ");
            }
        }
        catch(SQLException e){System.err.println(e.getMessage());}
    }
    
    //CRUD adicionar dados
    
    public void addRow(String table, String var){
        /*
            void addRow(tabela, dados):
                pede uma tabela e valores para serem adicionados;
                adiciona os valores passados na tabela escolhida;
        */
        
        try{
            connection = DriverManager.getConnection("jdbc:sqlite:bancoDeDados.db");
            Statement statement = connection.createStatement();
            statement.setQueryTimeout(30);
            
            statement.executeUpdate("INSERT INTO " + table + " VALUES( " + var + " )");
        }
        catch(SQLException e){System.err.println(e.getMessage());}
    }
    
    //CRUD dropar dados
    
    public void dropRow(String table, int id){
        /*
            void dropRow(tabela, id):
                pede uma tabela e o id da linha que sera excluida;
                deleta a linha com o id especificado;
        */
        
        try{
            connection = DriverManager.getConnection("jdbc:sqlite:bancoDeDados.db");
            Statement statement = connection.createStatement();
            statement.setQueryTimeout(30);
            
            statement.executeUpdate("DELETE FROM  " + table + " WHERE id=" + id);
        }
        catch(SQLException e){System.err.println(e.getMessage());}
    }
    
    //CRUD dropar tabela
    
    public void dropTable(String table){
        /*
            void dropRow(tabela):
                pede uma tabela que sera excluida;
                deleta a tabela especificada;
        */
        
        try{
            connection = DriverManager.getConnection("jdbc:sqlite:bancoDeDados.db");
            Statement statement = connection.createStatement();
            statement.setQueryTimeout(30);
            
            statement.executeUpdate("DROP TABLE " + table);
        }
        catch(SQLException e){System.err.println(e.getMessage());}
    }
    
    // CRUD limpar tabela
    
    public void clearTable(String table){
        /*
            void dropRow(tabela):
                pede uma tabela que sera limpa;
                apaga todos os dados da tabela;
        */
        
        try{
            connection = DriverManager.getConnection("jdbc:sqlite:bancoDeDados.db");
            Statement statement = connection.createStatement();
            statement.setQueryTimeout(30);
            
            statement.executeUpdate("DELETE FROM " + table);
        }
        catch(SQLException e){System.err.println(e.getMessage());}
    }
    
    public void closeBank(){
        try{
            connection = DriverManager.getConnection("jdbc:sqlite:bancoDeDados.db");
            Statement statement = connection.createStatement();
            statement.setQueryTimeout(30);
            connection.close();
        }
        catch(SQLException e){System.err.println(e.getMessage());}
    }
}
