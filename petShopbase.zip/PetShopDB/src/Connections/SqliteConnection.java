package Connections;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SqliteConnection { 
    
    private Connection connection;

    public void reset(){
        
        /*
            void reset():
                apaga todos as tabelas;
                cria todas as tabelas escenciais;
        */
        
      try {
        // Cria a conexão com o banco de dados
        connection = DriverManager.getConnection("jdbc:sqlite:base.db"); // cria ou abre um banco de dados com o nome entre parenteses
        Statement statement = connection.createStatement(); 
        statement.setQueryTimeout(30);  // Espera só por 30 segundos para conectar

        // roda as funções que apagam as tabelas
        initProductTable(statement); 
        initAnimalTable(statement);
        initAdoptionTable(statement); 
        initClientsTable(statement); 
        initFinanceTable(statement);
        initStaffTable(statement);
        initScheduleTable(statement);
        initMedicineTable(statement);
        
        } catch(SQLException e) {
            System.err.println(e.getMessage());
        }
        finally { //depois de resetar as tabelas
            try {
              if(connection != null){
                connection.close(); //fecha o banco de dados
              }
            } catch(SQLException e) {
              // Falhou também para fechar o arquivo
              System.err.println(e.getMessage());
            }
        }  
    }
    
    public void initProductTable(Statement statement){
        //função de resetar uma tabela:
        try{
            statement.executeUpdate("DROP TABLE IF EXISTS produtos");
            statement.executeUpdate("CREATE TABLE produtos (id integer PRIMARY KEY AUTOINCREMENT, nome STRING, valor DOUBLE)");
        }catch(SQLException e){System.err.println(e.getMessage());}
    }
    
    public void initAnimalTable(Statement statement){ //fk clientes
        //função de resetar uma tabela:
        try{
            statement.executeUpdate("DROP TABLE IF EXISTS animaisPacientes");
            statement.executeUpdate("CREATE TABLE animaisPacientes (id integer PRIMARY KEY AUTOINCREMENT, nome STRING, raça STRING, idade INT, cor STRING, idTutor integer"
                    + "idTutor integer, CONSTRAINT tutorFK FOREIGN KEY (idTutor) REFERENCES clientes (idTutor))");
        }catch(SQLException e){System.err.println(e.getMessage());}
    }
    
    public void initAdoptionTable(Statement statement){
        //função de resetar uma tabela:
        try{
            statement.executeUpdate("DROP TABLE IF EXISTS animaisParaAdoçao");
            statement.executeUpdate("CREATE TABLE animaisParaAdoçao (id integer PRIMARY KEY AUTOINCREMENT, nome STRING, raça STRING, idade INT, cor STRING, porte STRING, pelagem STRING)");
        }catch(SQLException e){System.err.println(e.getMessage());}
    }
    
    public void initClientsTable(Statement statement){
        //função de resetar uma tabela:
        try{
            statement.executeUpdate("DROP TABLE IF EXISTS clientes");
            statement.executeUpdate("CREATE TABLE clientes (id integer PRIMARY KEY AUTOINCREMENT, nome STRING, cpf INT, rg INT, endereço STRING)");
        }catch(SQLException e){System.err.println(e.getMessage());}
    }
    
    public void initFinanceTable(Statement statement){
        //função de resetar uma tabela:
        try{
            statement.executeUpdate("DROP TABLE IF EXISTS financeiro");
            statement.executeUpdate("CREATE TABLE financeiro (id integer PRIMARY KEY AUTOINCREMENT, entrada DOUBLE)");
        }catch(SQLException e){System.err.println(e.getMessage());}
    }
    
    public void initStaffTable(Statement statement){
        //função de resetar uma tabela:
        try{
            statement.executeUpdate("DROP TABLE IF EXISTS funcionários");
            statement.executeUpdate("CREATE TABLE funcionários (id integer PRIMARY KEY AUTOINCREMENT, nome STRING, cpf INT, rg INT, cargo STRING)");
        }catch(SQLException e){System.err.println(e.getMessage());}
    }
    
    public void initScheduleTable(Statement statement){
        //função de resetar uma tabela:
        try{
            statement.executeUpdate("DROP TABLE IF EXISTS horarioDeFuncionamento");
            statement.executeUpdate("CREATE TABLE horarioDeFuncionamento (id integer PRIMARY KEY AUTOINCREMENT, dia STRING, hora STRING)");
        }catch(SQLException e){System.err.println(e.getMessage());}
    }
    
    public void initVetTable(Statement statement){
        //função de resetar uma tabela:
        try{
            statement.executeUpdate("DROP TABLE IF EXISTS veterinários");
            statement.executeUpdate("CREATE TABLE veterinários (id integer PRIMARY KEY AUTOINCREMENT, nome STRING, cpf INT, rg INT, cargo STRING)");
        }catch(SQLException e){System.err.println(e.getMessage());}
    }
    
    public void initMedicineTable(Statement statement){
        //função de resetar uma tabela:
        try{
            statement.executeUpdate("DROP TABLE IF EXISTS procedimentosMedicos");
            statement.executeUpdate("CREATE TABLE procedimentosMedicos (id integer PRIMARY KEY AUTOINCREMENT, nome STRING, valor DPUBLE,"
                    + "idVet integer, CONSTRAINT VeterinárioFK FOREIGN KEY (idVet) REFERENCES Veterinários (idVet))");
        }catch(SQLException e){System.err.println(e.getMessage());}
    }
    
    public void initServicesTable(Statement statement){
        //função de resetar uma tabela:
        try{
            statement.executeUpdate("DROP TABLE IF EXISTS servicos");
            statement.executeUpdate("CREATE TABLE servicos (id integer PRIMARY KEY AUTOINCREMENT, nome STRING, valor DOUBLE,"
                    + "idStaff integer, CONSTRAINT funcionárioFK FOREIGN KEY (idStaff) REFERENCES funcionários (idStaff))");
        }catch(SQLException e){System.err.println(e.getMessage());}
    }
    
    //funções CRUD:
    
    //CRUD criar tabela:
    
    public void createTable(String tableName, String tableContents){
        /*
            void createTable(nome, conteúdos):
                pede um nome e conteúdos de uma tabela;
                cria uma tabela com o nome e váriaveis que foram especificadas
        */
        
        try{
            connection = DriverManager.getConnection("jdbc:sqlite:base.db");
            Statement statement = connection.createStatement();
            statement.setQueryTimeout(30);
            
            statement.executeUpdate("DROP TABLE IF EXISTS " + tableName);
            String s = "CREATE TABLE " + tableName + "(" + tableContents + ")";
            statement.executeUpdate(s);
        }
        catch(SQLException e){System.err.println(e.getMessage());}
    }
    
    //CRUD ler tabela:
    
    public void readTable(String table, String[] var){
        /*
            void readTable(tabela, o que ler):
                pede uma tabela e quais valores serão lidos;
                printa todas as entradas nos valores especificados da tabela escolhida
        */
        
        try{
            connection = DriverManager.getConnection("jdbc:sqlite:base.db");
            Statement statement = connection.createStatement();
            statement.setQueryTimeout(30);
            
            ResultSet rs = statement.executeQuery("SELECT * FROM " + table);
            while(rs.next()) {
                // Ler os dados inseridos
                for(int i = 0; i < var.length; i++ ){
                    System.out.println(var[i] + ": " + rs.getString(var[i]));
                }
                System.out.println(" --- ");
            }
        }
        catch(SQLException e){System.err.println(e.getMessage());}
    }
    
    //CRUD adicionar dados
    
    public String getTable(String table, String[] var){
         String s = "";
         
        try{
            System.out.println("init");
            connection = DriverManager.getConnection("jdbc:sqlite:base.db");
            Statement statement = connection.createStatement();
            statement.setQueryTimeout(30);
            
            ResultSet rs = statement.executeQuery("SELECT * FROM produtos");
            while(rs.next()) {
                // Ler os dados inseridos
                System.out.println(var.length + "n");
                for(int i = 0; i < var.length; i++ ){
                  s +=  var[i] + ": " + rs.getString(var[i]) + "";
                              System.out.println(rs.getString(var[i]));
                              System.out.println(table);
                }
                s += (" --- ");
            }
            return s;
        }
        catch(SQLException e){System.err.println(e.getMessage());}
        return null;
    }
    
    //CRUD adicionar dados
 
    public void addRow(String table, String var){
        /*
            void addRow(tabela, dados):
                pede uma tabela e valores para serem adicionados;
                adiciona os valores passados na tabela escolhida;
        */
        
        try{
            connection = DriverManager.getConnection("jdbc:sqlite:base.db");
            Statement statement = connection.createStatement();
            statement.setQueryTimeout(30);
            
            statement.executeUpdate("INSERT INTO " + table + " VALUES( " + var + " )");
        }
        catch(SQLException e){System.err.println(e.getMessage());}
    }
    
    //CRUD dropar dados
    
    public void dropRow(String table, int id){
        /*
            void dropRow(tabela, id):
                pede uma tabela e o id da linha que sera excluida;
                deleta a linha com o id especificado;
        */
        
        try{
            connection = DriverManager.getConnection("jdbc:sqlite:base.db");
            Statement statement = connection.createStatement();
            statement.setQueryTimeout(30);
            
            statement.executeUpdate("DELETE FROM  " + table + " WHERE id=" + id);
        }
        catch(SQLException e){System.err.println(e.getMessage());}
    }
    
    //CRUD dropar tabela
    
    public void dropTable(String table){
        /*
            void dropRow(tabela):
                pede uma tabela que sera excluida;
                deleta a tabela especificada;
        */
        
        try{
            connection = DriverManager.getConnection("jdbc:sqlite:base.db");
            Statement statement = connection.createStatement();
            statement.setQueryTimeout(30);
            
            statement.executeUpdate("DROP TABLE " + table);
        }
        catch(SQLException e){System.err.println(e.getMessage());}
    }
    
    // CRUD limpar tabela

    public void clearTable(String table){
        /*
            void dropRow(tabela):
                pede uma tabela que sera limpa;
                apaga todos os dados da tabela;
        */
        
        try{
            connection = DriverManager.getConnection("jdbc:sqlite:base.db");
            Statement statement = connection.createStatement();
            statement.setQueryTimeout(30);
            
            statement.executeUpdate("DELETE FROM " + table);
        }
        catch(SQLException e){System.err.println(e.getMessage());}
    }
    
    public void close(){
        try{
            connection = DriverManager.getConnection("jdbc:sqlite:base.db");
            Statement statement = connection.createStatement();
            statement.setQueryTimeout(30);
            connection.close();
        }
        catch(SQLException e){System.err.println(e.getMessage());}
    }
}
