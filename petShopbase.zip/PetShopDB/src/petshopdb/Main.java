package petshopdb;

import Connections.SqliteConnection;
import Graphics.AreaFuncionario;
//import Connections.CRUD;

public class Main {
    
    public static SqliteConnection db;
    
    public static void main(String[] args) {
        
        ////COMANDOS SQLITE////
        
        db = new SqliteConnection();
        
        String[] values = {"id", "nome", "valor"};
        //db.readTable("produtos", values);
        
        db.close();
        //System.out.println(
        //db.getTable("produtos", values));
        
        ////FIM COMANDOS////
        
        AreaFuncionario m = new AreaFuncionario();
        m.setVisible(true);

        
    }
    
}
